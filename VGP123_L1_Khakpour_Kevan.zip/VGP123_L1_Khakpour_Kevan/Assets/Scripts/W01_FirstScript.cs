﻿using UnityEngine;
using System.Collections;

public class W01_FirstScript : MonoBehaviour {

    public float speed = 5.0f;      // Accessible in Inspector
    private int score = 0;          // Not Accessible in Inspector
    bool isAlive = true;            // Not Accessible in Inspector

    // Called before Start()
    // - Script can be disabled and stil have this function called
    // - Only called once
    void Awake()
    {

    }

	// Use this for initialization
	void Start () {

        // Change speed value after game starts
        speed = 15.0f;

        // Prints current starting position of the GameObject the Script is attached to
        Debug.Log(gameObject.transform.position);
        Debug.Log(this.transform.position);
        Debug.Log(transform.position);
    }

    // Update is called once per frame
    // - Script must enabled
    // - Called multiple times based off when Graphics Renderer Update starts
    void Update () {

        // Prints message to console based off of framerate
        //Debug.Log("Game is Running...");

        //transform.Translate(Vector3.right);
        //transform.Translate(Vector3.right * Time.deltaTime);
        transform.Translate(Vector3.right * speed * Time.deltaTime);

        // transform.Translate(1,0,0);
        //transform.Translate(speed * Time.deltaTime, 0,0);
        //transform.Translate(new Vector3(speed,0,0) * Time.deltaTime);

    }

    // LateUpdate is called once per frame
    // - Script must enabled
    // - Called multiple times based off when Graphics Renderer Update is done
    void LateUpdate()
    {

    }

    // FixedUpdate is called once per frame
    // - Script must enabled
    // - Called multiple times based off of Physics Update
    void FixedUpdate()
    {

    }
}
